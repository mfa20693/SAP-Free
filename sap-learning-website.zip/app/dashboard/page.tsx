"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Menu,
  X,
  Search,
  User,
  Settings,
  HelpCircle,
  LogOut,
  ChevronDown,
  ChevronRight,
  FileText,
  Video,
  List,
  Plus,
  BarChart3,
  Calendar,
  Users,
  Activity,
  Download,
  Sun,
  Moon,
} from "lucide-react"

export default function Dashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [expandedSections, setExpandedSections] = useState({
    functional: true,
    technical: false,
    projectManager: false,
    administration: false,
  })
  const [darkMode, setDarkMode] = useState(false)
  const [currentView, setCurrentView] = useState("dashboard")

  const toggleSection = (section: keyof typeof expandedSections) => {
    setExpandedSections((prev) => ({
      ...prev,
      [section]: !prev[section],
    }))
  }

  const handleABAPClick = () => {
    setCurrentView("abap-video")
  }

  const currentDate = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  })

  return (
    <div className={`min-h-screen flex ${darkMode ? "dark bg-gray-900" : "bg-gray-50"}`}>
      {/* Navigation Sidebar */}
      <div
        className={`${sidebarOpen ? "w-80" : "w-16"} transition-all duration-300 ${darkMode ? "bg-gray-800 border-gray-700" : "bg-white border-gray-200"} border-r flex flex-col`}
      >
        {/* Sidebar Header */}
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <Button variant="ghost" size="sm" onClick={() => setSidebarOpen(!sidebarOpen)} className="p-2">
              {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
            {sidebarOpen && (
              <Button variant="ghost" size="sm" onClick={() => setDarkMode(!darkMode)} className="p-2">
                {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </Button>
            )}
          </div>

          {sidebarOpen && (
            <div className="mt-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
                  <User className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 dark:text-white">Guest User</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">SAP Consultant</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Navigation Menu */}
        <div className="flex-1 overflow-y-auto p-4">
          {sidebarOpen && (
            <nav className="space-y-2">
              {/* SAP Functional */}
              <div>
                <Button
                  variant="ghost"
                  className="w-full justify-between p-2 h-auto"
                  onClick={() => toggleSection("functional")}
                >
                  <div className="flex items-center space-x-2">
                    <FileText className="h-4 w-4" />
                    <span>SAP Functional</span>
                  </div>
                  {expandedSections.functional ? (
                    <ChevronDown className="h-4 w-4" />
                  ) : (
                    <ChevronRight className="h-4 w-4" />
                  )}
                </Button>
                {expandedSections.functional && (
                  <div className="ml-6 mt-2 space-y-1">
                    <Button variant="ghost" size="sm" className="w-full justify-start text-sm">
                      Modules (FI, CO, MM, SD)
                    </Button>
                    <Button variant="ghost" size="sm" className="w-full justify-start text-sm">
                      Documentation
                    </Button>
                    <Button variant="ghost" size="sm" className="w-full justify-start text-sm">
                      Training
                    </Button>
                  </div>
                )}
              </div>

              {/* SAP Technical */}
              <div>
                <Button
                  variant="ghost"
                  className="w-full justify-between p-2 h-auto"
                  onClick={() => toggleSection("technical")}
                >
                  <div className="flex items-center space-x-2">
                    <Video className="h-4 w-4" />
                    <span>SAP Technical</span>
                  </div>
                  {expandedSections.technical ? (
                    <ChevronDown className="h-4 w-4" />
                  ) : (
                    <ChevronRight className="h-4 w-4" />
                  )}
                </Button>
                {expandedSections.technical && (
                  <div className="ml-6 mt-2 space-y-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="w-full justify-start text-sm"
                      onClick={handleABAPClick}
                    >
                      ABAP
                    </Button>
                    <Button variant="ghost" size="sm" className="w-full justify-start text-sm">
                      Fiori
                    </Button>
                    <Button variant="ghost" size="sm" className="w-full justify-start text-sm">
                      HANA
                    </Button>
                    <Button variant="ghost" size="sm" className="w-full justify-start text-sm">
                      System Upgrades
                    </Button>
                  </div>
                )}
              </div>

              {/* SAP Project Manager */}
              <div>
                <Button
                  variant="ghost"
                  className="w-full justify-between p-2 h-auto"
                  onClick={() => toggleSection("projectManager")}
                >
                  <div className="flex items-center space-x-2">
                    <List className="h-4 w-4" />
                    <span>SAP Project Manager</span>
                  </div>
                  {expandedSections.projectManager ? (
                    <ChevronDown className="h-4 w-4" />
                  ) : (
                    <ChevronRight className="h-4 w-4" />
                  )}
                </Button>
                {expandedSections.projectManager && (
                  <div className="ml-6 mt-2 space-y-1">
                    <Button variant="ghost" size="sm" className="w-full justify-start text-sm">
                      Timelines
                    </Button>
                    <Button variant="ghost" size="sm" className="w-full justify-start text-sm">
                      Resources
                    </Button>
                    <Button variant="ghost" size="sm" className="w-full justify-start text-sm">
                      Risk Reports
                    </Button>
                  </div>
                )}
              </div>

              {/* SAP Administration */}
              <div>
                <Button
                  variant="ghost"
                  className="w-full justify-between p-2 h-auto"
                  onClick={() => toggleSection("administration")}
                >
                  <div className="flex items-center space-x-2">
                    <Settings className="h-4 w-4" />
                    <span>SAP Administration</span>
                  </div>
                  {expandedSections.administration ? (
                    <ChevronDown className="h-4 w-4" />
                  ) : (
                    <ChevronRight className="h-4 w-4" />
                  )}
                </Button>
                {expandedSections.administration && (
                  <div className="ml-6 mt-2 space-y-1">
                    <Button variant="ghost" size="sm" className="w-full justify-start text-sm">
                      User Management
                    </Button>
                    <Button variant="ghost" size="sm" className="w-full justify-start text-sm">
                      System Logs
                    </Button>
                    <Button variant="ghost" size="sm" className="w-full justify-start text-sm">
                      Performance
                    </Button>
                  </div>
                )}
              </div>
            </nav>
          )}
        </div>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-gray-200 dark:border-gray-700">
          {sidebarOpen ? (
            <div className="space-y-2">
              <Button variant="ghost" size="sm" className="w-full justify-start">
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
              <Button variant="ghost" size="sm" className="w-full justify-start">
                <HelpCircle className="h-4 w-4 mr-2" />
                Help
              </Button>
              <Button variant="ghost" size="sm" className="w-full justify-start text-red-600 hover:text-red-700">
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          ) : (
            <div className="space-y-2">
              <Button variant="ghost" size="sm" className="w-full p-2">
                <Settings className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" className="w-full p-2">
                <HelpCircle className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" className="w-full p-2 text-red-600">
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-hidden">
        <div className="h-full overflow-y-auto">
          {currentView === "abap-video" ? (
            <div className="h-full flex flex-col">
              <div className={`${darkMode ? "bg-blue-900" : "bg-blue-600"} text-white p-4`}>
                <div className="max-w-7xl mx-auto flex items-center justify-between">
                  <div>
                    <h1 className="text-2xl font-bold">ABAP Programming Tutorial</h1>
                    <p className="text-blue-100">1 - ABAP Programming - ABAP Editor Part1</p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentView("dashboard")}
                    className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                  >
                    Back to Dashboard
                  </Button>
                </div>
              </div>

              <div className="flex-1 p-6">
                <div className="max-w-7xl mx-auto">
                  <div className="aspect-video w-full bg-black rounded-lg overflow-hidden">
                    <iframe
                      src="https://www.youtube.com/embed/EqSizBH2n0w?si=3TryUQ6TbZA-QGi5"
                      title="ABAP Programming - ABAP Editor Part1"
                      className="w-full h-full"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    />
                  </div>

                  <div className="mt-6">
                    <Card>
                      <CardHeader>
                        <CardTitle>About this Tutorial</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-600 dark:text-gray-400">
                          Learn the fundamentals of ABAP programming with this comprehensive tutorial covering the ABAP
                          Editor. This is the first part of a series designed to help you master SAP ABAP development.
                        </p>
                        <div className="mt-4 flex flex-wrap gap-2">
                          <Badge>ABAP</Badge>
                          <Badge>Programming</Badge>
                          <Badge>SAP Technical</Badge>
                          <Badge>Beginner</Badge>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <>
              {/* Welcome Banner */}
              <div className={`${darkMode ? "bg-blue-900" : "bg-blue-600"} text-white p-6`}>
                <div className="max-w-7xl mx-auto">
                  <h1 className="text-3xl font-bold mb-2">Welcome, Guest User!</h1>
                  <p className="text-blue-100 mb-4">{currentDate} • 3 pending tasks</p>

                  <div className="relative max-w-md">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Tell me what you want to do..."
                      className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-blue-200"
                    />
                  </div>
                </div>
              </div>

              {/* Dashboard Content */}
              <div className="max-w-7xl mx-auto p-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                  {/* Recent Activity */}
                  <Card className="lg:col-span-2">
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Activity className="h-5 w-5" />
                        <span>Recent Activity</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center">
                              <FileText className="h-4 w-4 text-green-600 dark:text-green-400" />
                            </div>
                            <div>
                              <p className="font-medium">Transaction SE80 accessed</p>
                              <p className="text-sm text-gray-500">2 hours ago</p>
                            </div>
                          </div>
                          <Badge variant="secondary">ABAP</Badge>
                        </div>

                        <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center">
                              <BarChart3 className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                            </div>
                            <div>
                              <p className="font-medium">Financial report generated</p>
                              <p className="text-sm text-gray-500">4 hours ago</p>
                            </div>
                          </div>
                          <Badge variant="secondary">FI</Badge>
                        </div>

                        <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-orange-100 dark:bg-orange-900 rounded-full flex items-center justify-center">
                              <Users className="h-4 w-4 text-orange-600 dark:text-orange-400" />
                            </div>
                            <div>
                              <p className="font-medium">User role updated</p>
                              <p className="text-sm text-gray-500">1 day ago</p>
                            </div>
                          </div>
                          <Badge variant="secondary">Admin</Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Quick Tasks */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Plus className="h-5 w-5" />
                        <span>Quick Tasks</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <Button className="w-full justify-start bg-blue-600 hover:bg-blue-700">
                          <FileText className="h-4 w-4 mr-2" />
                          Create Ticket
                        </Button>
                        <Button variant="outline" className="w-full justify-start bg-transparent">
                          <BarChart3 className="h-4 w-4 mr-2" />
                          Run Report
                        </Button>
                        <Button variant="outline" className="w-full justify-start bg-transparent">
                          <Calendar className="h-4 w-4 mr-2" />
                          Schedule Meeting
                        </Button>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Training/Updates */}
                  <Card className="lg:col-span-2">
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Video className="h-5 w-5" />
                        <span>Training & Updates</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="p-4 border rounded-lg hover:shadow-md transition-shadow">
                          <h3 className="font-semibold mb-2">Latest SAP S/4HANA Release Notes</h3>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                            Discover new features and improvements in the latest release
                          </p>
                          <Button size="sm" className="w-full">
                            <Download className="h-4 w-4 mr-2" />
                            Download
                          </Button>
                        </div>

                        <div className="p-4 border rounded-lg hover:shadow-md transition-shadow">
                          <h3 className="font-semibold mb-2">ABAP Development Best Practices</h3>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                            Learn modern ABAP coding standards and techniques
                          </p>
                          <Button size="sm" variant="outline" className="w-full bg-transparent">
                            <Video className="h-4 w-4 mr-2" />
                            Watch Video
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* System Health */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Activity className="h-5 w-5" />
                        <span>System Health</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>CPU Usage</span>
                            <span>68%</span>
                          </div>
                          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                            <div className="bg-blue-600 h-2 rounded-full" style={{ width: "68%" }}></div>
                          </div>
                        </div>

                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>Memory Usage</span>
                            <span>45%</span>
                          </div>
                          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                            <div className="bg-green-600 h-2 rounded-full" style={{ width: "45%" }}></div>
                          </div>
                        </div>

                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>Active Users</span>
                            <span>1,247</span>
                          </div>
                          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                            <div className="bg-orange-600 h-2 rounded-full" style={{ width: "82%" }}></div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
