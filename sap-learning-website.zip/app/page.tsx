"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, Calendar, Users, Award } from "lucide-react"
import { AuthModal } from "@/components/auth-modal"

export default function HomePage() {
  const [authModal, setAuthModal] = useState<{ isOpen: boolean; mode: "login" | "signup" }>({
    isOpen: false,
    mode: "login",
  })

  const openAuthModal = (mode: "login" | "signup") => {
    setAuthModal({ isOpen: true, mode })
  }

  const closeAuthModal = () => {
    setAuthModal({ isOpen: false, mode: "login" })
  }

  const switchAuthMode = () => {
    setAuthModal((prev) => ({
      ...prev,
      mode: prev.mode === "login" ? "signup" : "login",
    }))
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Hero Section */}
      <section className="px-6 py-16 md:py-24">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6 leading-tight">Learn SAP on your terms</h1>
          <p className="text-lg md:text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
            Stay updated with the latest innovations through expert-led SAP learning resources, available whenever you
            need them.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button
              variant="outline"
              size="lg"
              className="w-full sm:w-auto px-8 py-3 text-base bg-transparent"
              onClick={() => openAuthModal("login")}
            >
              Log in
            </Button>
            <Button
              size="lg"
              className="w-full sm:w-auto px-8 py-3 text-base bg-blue-600 hover:bg-blue-700"
              onClick={() => openAuthModal("signup")}
            >
              Register now
            </Button>
          </div>
        </div>
      </section>

      {/* Search/Intro Section */}
      <section className="px-6 py-12 bg-white">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-2xl md:text-3xl font-semibold text-gray-900 mb-6">What would you like to learn today?</h2>
          <div className="relative max-w-2xl mx-auto">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <Input
              type="text"
              placeholder="Find self-paced courses, certification exams, and more."
              className="pl-12 pr-4 py-4 text-base rounded-lg border-2 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
            />
          </div>
        </div>
      </section>

      {/* Featured Content Section */}
      <section className="px-6 py-16 bg-gradient-to-r from-blue-600 to-indigo-700 text-white">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-start gap-4 mb-6">
            <Users className="h-8 w-8 text-blue-200 flex-shrink-0 mt-1" />
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Business AI Insights: Latest Updates & Live Demos</h2>
              <p className="text-lg md:text-xl text-blue-100 mb-6 leading-relaxed">
                Discover the newest advancements in Business AI with expert insights and live demonstrations from
                industry leaders.
              </p>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 mb-8">
            <div className="flex items-center gap-3 mb-4">
              <Calendar className="h-6 w-6 text-blue-200" />
              <span className="text-blue-100 font-medium">Upcoming Live Session</span>
            </div>
            <p className="text-lg mb-4">
              Join our live session on <strong>August 19th, 2025, at 5 PM CEST</strong> to explore the latest trends and
              boost your AI skills.
            </p>
          </div>

          <Button size="lg" className="bg-white text-blue-600 hover:bg-blue-50 px-8 py-3 text-base font-semibold">
            Explore Now
          </Button>
        </div>
      </section>

      {/* Certification Section */}
      <section className="px-6 py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex justify-center mb-6">
            <Award className="h-12 w-12 text-blue-600" />
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Get Certified!</h2>
          <p className="text-lg md:text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Choose the right certification to advance your career.
          </p>
          <Button size="lg" className="bg-blue-600 hover:bg-blue-700 px-8 py-3 text-base font-semibold">
            Find Your Path
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-6 py-8 bg-gray-900 text-gray-300">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-sm">© 2025 SAP Learning Platform. All rights reserved.</p>
        </div>
      </footer>

      <AuthModal
        isOpen={authModal.isOpen}
        onClose={closeAuthModal}
        mode={authModal.mode}
        onSwitchMode={switchAuthMode}
      />
    </div>
  )
}
